import { NgModule } from '@angular/core';
import { BrowserModule } from '@angular/platform-browser';

import { AppRoutingModule } from './app-routing.module';
import { AppComponent } from './app.component';
import { CounterMessageComponent } from './counter-message/counter-message.component';
import { CounterButtonComponent } from './counter-button/counter-button.component';
import { InputFormComponent } from './input-form/input-form.component';
import { InputTableComponent } from './input-table/input-table.component';

@NgModule({
  declarations: [
    AppComponent,
    CounterMessageComponent,
    CounterButtonComponent,
    InputFormComponent,
    InputTableComponent
  ],
  imports: [
    BrowserModule,
    AppRoutingModule
  ],
  providers: [],
  bootstrap: [AppComponent]
})
export class AppModule { }
