import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'app-input-form',
  templateUrl: './input-form.component.html',
  styleUrls: ['./input-form.component.scss']
})
export class InputFormComponent implements OnInit {


  Name:String="";

  constructor() { }

  ngOnInit(): void {
  } 

   onsubmit(event:any) :void
   {
     this.Name+=event.target.value+" + "
   }

}
