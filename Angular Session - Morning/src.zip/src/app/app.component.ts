import { Component } from '@angular/core';

@Component({
  selector: 'app-root',
  templateUrl: './app.component.html',
  styleUrls: ['./app.component.scss']
})
export class AppComponent {
  title = 'counter';
  counter: number = 0;

  incrementCount(): void {
    this.counter = this.counter + 1;
  }
}
