import { Component, Input, OnInit } from '@angular/core';

@Component({
  selector: 'app-input-table',
  templateUrl: './input-table.component.html',
  styleUrls: ['./input-table.component.scss']
})
export class InputTableComponent implements OnInit {

  @Input() Name:any;

  constructor() { }

  ngOnInit(): void {
  }

}
 