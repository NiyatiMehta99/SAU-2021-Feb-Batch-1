import { Component, Input, OnInit } from '@angular/core';

@Component({
  selector: 'app-counter-message',
  templateUrl: './counter-message.component.html',
  styleUrls: ['./counter-message.component.scss']
})
export class CounterMessageComponent implements OnInit {
  @Input('counterClicked') counterClicked:any;

  Name:string="";
  constructor() { }

  ngOnInit(): void {
  }

  onsubmit(event:any):void
  {
    this.Name+=event.target.value+" | "
  }

}
