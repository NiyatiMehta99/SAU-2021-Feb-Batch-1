package com.example.au.couchbasedemo.model;

import java.util.List;

import org.springframework.data.annotation.Id;
import org.springframework.data.couchbase.core.mapping.Document;
import org.springframework.data.couchbase.core.mapping.Field;

import com.sun.istack.NotNull;

@Document
public class Movie {
	
	@Id
	String id;
	
	@NotNull
	@Field
	String name;
	
	@NotNull
	@Field
	List<String> city;
	
	@Field
    List<String> tags;
	
	public String getName()
	{
		return name;
	}
	
	public void setName(String name)
	{
		this.name=name;
	}
	
	public List<String> getCity()
	{
		return city;
	}
	
	public void setCity(List<String> city)
	{
		this.city=city;
	}
	
	public List<String> getTags() {
		return tags;
	}

	public void setTags(List<String> tags) {
		this.tags = tags;
	}
	
	public String getId() {
		return id;
	}
	
	public Movie(String id, String name, List<String> city, List<String> tags) {
		super();
		this.id = id;
		this.name = name;
		this.city = city;
		this.tags = tags;
	}
	

}
