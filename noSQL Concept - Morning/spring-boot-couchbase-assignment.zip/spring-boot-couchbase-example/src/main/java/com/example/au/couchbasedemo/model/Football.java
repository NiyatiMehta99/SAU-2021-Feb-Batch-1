package com.example.au.couchbasedemo.model;

import java.util.List;

import org.springframework.data.annotation.Id;
import org.springframework.data.couchbase.core.mapping.Document;
import org.springframework.data.couchbase.core.mapping.Field;

import com.sun.istack.NotNull;

@Document
public class Football {
	
	@Id
	String id;
	
	@NotNull
	@Field
	String footballer;
	
	@NotNull
	@Field
	int goals;
	
	public String getId()
	{
		return id;
	}
	
	public void setId(String id)
	{
		this.id=id;
	}
	
	public String getfootballer()
	{
		return footballer;
	}
	
	public void setfootballer(String footballer)
	{
		this.footballer=footballer;
	}
	

	public int getGoals()
	{
		return goals;
	}
	
	public void setGoals(int goals)
	{
		this.goals=goals;
	}
	
	public Football(String id, String footballer,int goals)
	{
		this.id=id;
		this.footballer=footballer;
		this.goals=goals;
	}
}


